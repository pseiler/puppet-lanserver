### Translations

Kiwi IRC has been translated to 26 different languages:
* Albanian
* Bosnian
* Catalan
* Čeština
* Deutsch
* English
* Español
* Español (Latino America)
* Français
* Galego
* Greek
* Hebrew
* Italiano
* Korean
* Македонски
* Nederlands
* Norsk
* Polski
* Português (Brasil)
* Română
* русский
* Srpski
* Türkçe
* Українська
* Tiếng Việt
* 中文 (繁體) (Simplified chinese)


Current translations are handled by the following (only listing translators willing to be publically mentioned):

* **Norwegian** - Olav Lindekleiv (https://github.com/oal)
* **Albanian** - Besnik Bleta (besnik@programeshqip.org)
* **Ukrainian** - Artem Polivanchuk (polivanchuk@outlook.com)
* **Catalan** - NeoMahler (https://github.com/NeoMahler)
* **Bosnian** - Predsjednik (predsjednik@live.com)
* **Polish** - Piotr Doroszewski (piotrekd at vivaldi dot net)
* **Serbian** - Stefan C. (admin@xshellz.com)
* **Galicia** - Chema Casanova (https://github.com/txenoo)
